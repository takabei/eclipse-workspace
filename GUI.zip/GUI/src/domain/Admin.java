package domain;

public class Admin extends User{
	
	public Admin(String table, String username, String password) {
		super(table,username,password);
	}

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
