package utils;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public interface NodeTWO {

	JTabbedPane getJTabbedPane();

}
