package utils;

import javax.swing.JPanel;

public interface Node {
	JPanel getJpanel();
}
